$(function(){

    console.log("jQuery is ready");


    $("#get-songs-from-api").click(function(){

        console.log("get songs button was clicked");

        $.ajax({

            dataType: "json",
            url: "getsongs.php",
            success: function(songs){

                console.log("here is the list of songs I got from the server : ");
                console.log(songs);

                $.each(songs, function(i,song){

                    var songstring = '<li>Title:' + song.title + 'Artist' + song.artist + '</li>';
                    $(songstring).appendTo('#songs').hide().fadeIn();
                

                    // start from 14  

                })
            }
        
        });
});

$("#add-song").click(function(){

    var song = {

        title: $('#artist').val(),
        artist: $('#title').val()
    };


    $.ajax({

        type:'GET',
        url : 'putsongs.php',
        dataType: "json",
        data: song,
        success:function(newsong){

        
            console.log("here is the song the server send back to us");
            console.log(newsong);

            var songstring = '<li>Title: ' + newsong.title + 'Artist:' + newsong.artist + '</li>';
            $(songstring).appendTo('#songs').hide().fadeIn();


        }
    })


});
});