﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(function () {

    $(document).on("click", ".edit-product-button", function (event) {

        event.preventDefault();

        var myProductId = $(this).data('id');
        var myProductName = $(this).parent().find('.product-name').html();
        var myProductPrice = $(this).parent().find('.product-price').html().replace("$", "");
        var myProductDescription = $(this).parent().find('.product-description').html();

        console.log("clicked button # " + myProductId);
        console.log("name = " + myProductName);
        console.log("price = " + myProductPrice);
        console.log("desc= " + myProductDescription);


    });


    $("#save-product").click(function () {
        var Product = {

            "Id": $('#Id').val(),
            "Name": $('#Name').val(),
            "price": $('#Price').val(),
            "Description": $("#Description").val(),

        }



    });


        console.log(Product);
        doProductUpdate(Product);

        function doProductUpdate(product) {
            $.ajax({

                dataType: "json",
                url: '/products/ProcessEditReturnOneItem',
                data: product,
                success: function (data) {
                    console.log(data);
                    $("#card-number-" + Product.Id).html(data);
                }
            });
        };
    });
