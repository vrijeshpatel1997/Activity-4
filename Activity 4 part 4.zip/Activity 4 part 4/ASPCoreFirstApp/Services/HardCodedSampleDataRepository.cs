﻿using ASPCoreFirstApp.Models;
using Bogus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreFirstApp.Services
{
    public class HardCodedSampleDataRepository : IProductDataService
    {

        static List<ProductModel> productList;




        public HardCodedSampleDataRepository()
        {
            productList = new List<ProductModel>();

            productList.Add(new ProductModel(1, "mousepad", 6.99m, " a square oeice  of plastix "));

            productList.Add(new ProductModel(2, "web cam", 44.40m, " enables u to attend zoom metting"));

            productList.Add(new ProductModel(3, "4 tb usb drive " ,130.00m, "back up"));
            productList.Add(new ProductModel(4, "keyboard ", 530.00m, "write"));

            for(int i = 0; i < 100; i++)
            {

                productList.Add(new Faker<ProductModel>()
                      .RuleFor(p => p.Id, i + 5)
                      .RuleFor(p => p.Name, f => f.Commerce.ProductName())
                      .RuleFor(p => p.Price, f => f.Random.Decimal(100))
                      .RuleFor(p => p.Description, f => f.Rant.Review())
                      );

        }
    }

        


        public List<ProductModel> AllProducts()
        {
            return productList;
        }

        public bool Delete(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public ProductModel GetProductId(int id)
        {
            throw new NotImplementedException();
        }

        public int Insert(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public List<ProductModel> SearchProducts(string searchTerm)
        {
            throw new NotImplementedException();
        }

        public int Update(ProductModel product)
        {
            throw new NotImplementedException();
        }
    }
}
