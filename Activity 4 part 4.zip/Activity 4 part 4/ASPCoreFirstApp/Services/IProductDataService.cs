﻿using ASPCoreFirstApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreFirstApp.Services
{
    interface IProductDataService
    {

        List<ProductModel> AllProducts();
        List<ProductModel> SearchProducts(string searchTerm);
        ProductModel GetProductId(int id);
        int Insert(ProductModel product);
        bool Delete(ProductModel product);

        int Update(ProductModel product);


    }
}
