﻿using ASPCoreFirstApp.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreFirstApp.Services
{
    public class ProductDAO : IProductDataService
    {

        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";


        public List<ProductModel> AllProducts()
        {

            List<ProductModel> foundProducts = new List<ProductModel>();


            string sqlStatement = "SELECT * FROM dbo.Products";

            using (SqlConnection connetion = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connetion);

                try
                {

                    connetion.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundProducts.Add(new ProductModel((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]));

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
                return foundProducts;


            }
            throw new NotImplementedException();
        }

        public bool Delete(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public ProductModel GetProductId(int id)
        {


            ProductModel foundProduct = null;


            string sqlStatement = "SELECT * FROM dbo.Products WHERE Id = @id";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.AddWithValue("@id", id);

                try
                {

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundProduct = new ProductModel((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]);
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };

                return foundProduct;
            }


        }

        public int Insert(ProductModel product)
        {
            throw new NotImplementedException();
        }

        public List<ProductModel> SearchProducts(string searchTerm)
        {

            List<ProductModel> foundProducts = new List<ProductModel>();

            string sqlStatement = "SELECT * FROM dbo.Products WHERE Name LIKE @Name";
            using (SqlConnection connetion = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connetion);

                try
                {

                    connetion.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundProducts.Add(new ProductModel((int)reader[0], (string)reader[1], (decimal)reader[2], (string)reader[3]));

                        throw new NotImplementedException();
                    }
                }

                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);

                };
            }
            return foundProducts;





        }

        public int Update(ProductModel product)
        {

            int newidnumber = -1;

            using(SqlConnection connenction  = new SqlConnection(connectionString))
            {

                string query = "UPDATE dbo.Products SET Name = @Name, Price = @Price, Description = @Description WHERE id = @Id";


                SqlCommand mycommand = new SqlCommand(query, connenction);
                mycommand.Parameters.AddWithValue("@Id", product.Id);
                mycommand.Parameters.AddWithValue("@Name", product.Name);
                mycommand.Parameters.AddWithValue("@Price", product.Price);
                mycommand.Parameters.AddWithValue("@Description", product.Description);


                try
                {

                    connenction.Open();
                    newidnumber = Convert.ToInt32(mycommand.ExecuteScalar());

                }catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
                return newidnumber;
            }
            throw new NotImplementedException();
        }
    }
}