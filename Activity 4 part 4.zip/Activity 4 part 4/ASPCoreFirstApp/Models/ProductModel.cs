﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreFirstApp.Models
{
    public class ProductModel
    {

        [DisplayName("id number")]
        public int Id { get; set; }


        [DisplayName("product name")]
        public string Name { get; set; }


        [DisplayName("cost to customer ")]
        public decimal Price { get; set; }


        [DisplayName("what u get")]
        public string Description { get; set; }

        public ProductModel(int id, string name, decimal price, string description)
        {
            Id = id;
            Name = name;
            Price = price;
            Description = description;
        }

        public ProductModel()
        {

        }
    }

}
