﻿using ASPCoreFirstApp.Models;
using ASPCoreFirstApp.Services;
using Bogus;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ASPCoreFirstApp.Controllers
{
    public class ProductsController : Controller
    {


        ProductDAO repository = new ProductDAO();


        public ProductsController()
        {
            repository = new ProductDAO();
        }
        public IActionResult Index()
        {




            HardCodedSampleDataRepository repository = new HardCodedSampleDataRepository();







            return View(repository.AllProducts());
        }



        public IActionResult Message()
        {

            return View();
        }



        public IActionResult SearchResults (string searchTerm)
        {

            List<ProductModel> productList = repository.SearchProducts(searchTerm);
            return View("index", productList);
        }


        public IActionResult showOneProduct( int id)
        {
            return View(repository.GetProductId(id));
        }


        public IActionResult showEditForm(int Id)
        {
            return View(repository.GetProductId(Id));

        }


        public IActionResult ProcessEdit(ProductModel product)
        {
            repository.Update(product);
            return View("index", repository.AllProducts());
        }

        public IActionResult ProcessEditReturnOneItem(ProductModel product)
        {
            repository.Update(product);
            return PartialView("_productCard", repository.GetProductId(product.Id));
        }

        public IActionResult SearchForm()
        {
            return View();
        }
        public IActionResult welcome ()
        {

            ViewBag.name = "Vrijesh";
            ViewBag.secretNumber = 13;
            return View();
        }
    }
}
    