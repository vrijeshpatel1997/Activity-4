﻿using AJAXExample.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AJAXExample.Controllers
{
    public class CustomerController : Controller



    {



        List<CustomerModel> customers = new List<CustomerModel>();

        public CustomerController()
        {
            //add new customers to a list
            customers.Add(new CustomerModel(0, "Don", 56));
            customers.Add(new CustomerModel(1, "vrijesh", 20));
            customers.Add(new CustomerModel(2, "David", 5));
            customers.Add(new CustomerModel(3, "Mon", 60));
            customers.Add(new CustomerModel(4, "Jill ", 25));
            customers.Add(new CustomerModel(5, "Mindy", 15));
        }

        public IActionResult Index()
        {
            return View(customers);
        }


        public IActionResult ShowOnePerson(int id)
        {
            return PartialView(customers.FirstOrDefault(c => c.Id == id));
        }
    }
}
