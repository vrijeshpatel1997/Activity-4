﻿using ButtonGridNew.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ButtonGridNew.Controllers
{
    public class ButtonController : Controller
    {


        static List<ButtonModel> buttons = new List<ButtonModel>();

        Random random = new Random();
        const int GRID_SIZE = 25;
        public IActionResult Index()
        {

            buttons = new List<ButtonModel>();



            for(int i = 0; i < GRID_SIZE; i++)
            {

                buttons.Add(new ButtonModel(i, random.Next(4)));
            }
         


            return View("index", buttons);
        }

        public IActionResult HandleButtonClick(string buttonNumber)
        {
            int bN = int.Parse(buttonNumber);
            buttons.ElementAt(bN).ButtonState = (buttons.ElementAt(bN).ButtonState + 1) % 4;

            return View("Index", buttons);
        }


        public IActionResult ShowOneButton (int buttonNumber)
        {
            buttons.ElementAt(buttonNumber).ButtonState = (buttons.ElementAt(buttonNumber).ButtonState + 1) % 4;


            return PartialView(buttons.ElementAt(buttonNumber));
        }
    }
}
