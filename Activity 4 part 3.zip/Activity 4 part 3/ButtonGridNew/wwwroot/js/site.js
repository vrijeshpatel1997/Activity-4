﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(function () {

    console.log("page is ready");

    $(".game-button").click(function (event) {

        event.preventDefault();
        var buttonNumber = $(this).val();
        console.log("button number" + buttonNumber + "was clicked");
        doButtonUpdate(buttonNumber);

    });
});

function doButtonUpdate(buttonNumber) {
    $.ajax({

        dataType: "json",
        method: 'POST',
        url: '/button/ShowOneButton',
        data: {

            "buttonNumber": buttonNumber
        },

        success: function (data) {


            console.log(data);
            $("#" + buttonNumber).html(data);
        }



    });

};